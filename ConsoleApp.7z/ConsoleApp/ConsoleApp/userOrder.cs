public class userOrder

{
	Order order = new Order ();

	public void Display()
	{
		Console.WriteLine(order.ToString());
	}

	
}